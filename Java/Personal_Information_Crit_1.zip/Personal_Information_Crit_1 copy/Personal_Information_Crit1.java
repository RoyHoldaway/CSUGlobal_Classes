public class Personal_Information_Crit1 {
    public static void main(String[] args) {
        String firstName = "Daberious";
        String lastName = "Jones";
        String address = "918 Fake St";
        String city = "Fort Collins";
        String zipCode = "80526";

        // Print user input information
        System.out.println("User entered information:");
        System.out.println("First name: " + firstName);
        System.out.println("Last name: " + lastName);
        System.out.println("Street address: " + address);
        System.out.println("City: " + city);
        System.out.println("Zip code: " + zipCode);
    }
}